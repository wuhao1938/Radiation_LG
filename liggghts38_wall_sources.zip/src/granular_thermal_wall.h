#ifndef LMP_GRANULAR_THERMAL_WALL_H
#define LMP_GRANULAR_THERMAL_WALL_H

#include <array>
#include <vector>

namespace LAMMPS_NS {

class GranularThermalWall {
public:
    typedef std::array<double, 3> Vector;

    struct Hit {
        double distance;
        double normal_projection;
        bool cylinder_interior;
    };

    GranularThermalWall();
    void set_primitive(int axis, int parameter_count, const double *parameters);
    void set_triangles(const double *coordinates, int coordinate_count);
    void set_periodic(const bool *periodic, const double *lengths);
    double distance(const double *point) const;
    bool first_hit(const double *point, const double *direction,
                   double length, Hit &hit) const;
    double penetration(const double *point, const double *direction,
                       double radius, const Hit &hit) const;
    double angular_limit(const double *point, double radius, Vector &axis) const;

private:
    enum Kind { PLANE, CYLINDER, TRIANGLES };

    struct Box {
        Vector lower, upper;
        Box();
        void include(const Vector &point);
        double distance_squared(const Vector &point) const;
        bool intersects(const Vector &point, const Vector &direction, double length) const;
    };

    struct Triangle {
        Vector a, ab, ac, normal;
        Box bounds;
    };

    struct Node {
        Box bounds;
        int begin, end, left, right;
    };

    Kind kind_;
    int axis_;
    double parameters_[3];
    std::vector<Triangle> triangles_;
    std::vector<Node> nodes_;
    bool coplanar_;
    Vector plane_normal_;
    std::vector<Vector> periodic_shifts_;

    double radial_distance(const double *point) const;
    int build_node(int begin, int end);
    static double triangle_distance_squared(const Triangle &face, const Vector &point);
    double nearest_squared(int node, const Vector &point, double best) const;
    bool first_triangle_hit(int node, const Vector &point, const Vector &direction,
                            double tolerance, Hit &hit) const;
};

}  // namespace LAMMPS_NS

#endif
