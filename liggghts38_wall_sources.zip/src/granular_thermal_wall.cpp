#include "granular_thermal_wall.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace LAMMPS_NS {
namespace {

typedef GranularThermalWall::Vector Vector;

Vector make_vector(const double *x)
{
    return {{x[0], x[1], x[2]}};
}

Vector operator+(const Vector &a, const Vector &b)
{
    return {{a[0]+b[0], a[1]+b[1], a[2]+b[2]}};
}

Vector operator-(const Vector &a, const Vector &b)
{
    return {{a[0]-b[0], a[1]-b[1], a[2]-b[2]}};
}

Vector operator*(double s, const Vector &a)
{
    return {{s*a[0], s*a[1], s*a[2]}};
}

double dot(const Vector &a, const Vector &b)
{
    return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
}

Vector cross(const Vector &a, const Vector &b)
{
    return {{a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]}};
}

double norm_squared(const Vector &a)
{
    return dot(a, a);
}

double segment_distance_squared(const Vector &offset, const Vector &edge)
{
    const double t = std::max(0.0, std::min(1.0, dot(offset, edge)/norm_squared(edge)));
    return norm_squared(offset - t*edge);
}

}  // namespace

GranularThermalWall::GranularThermalWall()
    : kind_(PLANE), axis_(0), parameters_(), coplanar_(false), plane_normal_()
{
}

void GranularThermalWall::set_primitive(int axis, int parameter_count, const double *parameters)
{
    axis_ = axis;
    kind_ = parameter_count == 1 ? PLANE : CYLINDER;
    std::copy(parameters, parameters + parameter_count, parameters_);
}

GranularThermalWall::Box::Box()
{
    lower.fill(std::numeric_limits<double>::infinity());
    upper.fill(-std::numeric_limits<double>::infinity());
}

void GranularThermalWall::Box::include(const Vector &point)
{
    for (int a = 0; a < 3; ++a) {
        lower[a] = std::min(lower[a], point[a]);
        upper[a] = std::max(upper[a], point[a]);
    }
}

double GranularThermalWall::Box::distance_squared(const Vector &point) const
{
    double distance2 = 0.0;
    for (int a = 0; a < 3; ++a) {
        const double gap = std::max(0.0, std::max(lower[a]-point[a], point[a]-upper[a]));
        distance2 += gap*gap;
    }
    return distance2;
}

bool GranularThermalWall::Box::intersects(const Vector &point, const Vector &direction,
                                         double length) const
{
    double first = 0.0, last = length;
    for (int a = 0; a < 3; ++a) {
        if (direction[a] == 0.0) {
            if (point[a] < lower[a] || point[a] > upper[a]) return false;
            continue;
        }
        double t0 = (lower[a] - point[a])/direction[a];
        double t1 = (upper[a] - point[a])/direction[a];
        if (t0 > t1) std::swap(t0, t1);
        first = std::max(first, t0);
        last = std::min(last, t1);
        if (first > last) return false;
    }
    return true;
}

void GranularThermalWall::set_triangles(const double *coordinates, int coordinate_count)
{
    kind_ = TRIANGLES;
    triangles_.clear();
    triangles_.reserve(coordinate_count/9);
    nodes_.clear();
    Box bounds;
    for (int i = 0; i+8 < coordinate_count; i += 9) {
        Triangle face;
        face.a = make_vector(coordinates+i);
        const Vector b = make_vector(coordinates+i+3), c = make_vector(coordinates+i+6);
        face.ab = b-face.a;
        face.ac = c-face.a;
        const Vector normal = cross(face.ab, face.ac);
        const double normal2 = norm_squared(normal);
        if (!(normal2 > 0.0)) continue;
        face.normal = (1.0/std::sqrt(normal2))*normal;
        face.bounds.include(face.a);
        face.bounds.include(b);
        face.bounds.include(c);
        bounds.include(face.bounds.lower);
        bounds.include(face.bounds.upper);
        triangles_.push_back(face);
    }
    coplanar_ = !triangles_.empty();
    if (!coplanar_) return;
    const Vector point = triangles_.front().a;
    plane_normal_ = triangles_.front().normal;
    const double tolerance = 1.e-10*std::sqrt(norm_squared(bounds.upper-bounds.lower));
    for (std::size_t k = 1; k < triangles_.size(); ++k) {
        const Triangle &face = triangles_[k];
        const Vector a = face.a-point;
        if (std::fabs(dot(a,plane_normal_)) > tolerance ||
            std::fabs(dot(a+face.ab,plane_normal_)) > tolerance ||
            std::fabs(dot(a+face.ac,plane_normal_)) > tolerance) {
            coplanar_ = false;
            break;
        }
    }
    build_node(0, static_cast<int>(triangles_.size()));
}

void GranularThermalWall::set_periodic(const bool *periodic, const double *lengths)
{
    periodic_shifts_.clear();
    for (int i = -int(periodic[0]); i <= int(periodic[0]); ++i)
        for (int j = -int(periodic[1]); j <= int(periodic[1]); ++j)
            for (int k = -int(periodic[2]); k <= int(periodic[2]); ++k)
                if (i != 0 || j != 0 || k != 0)
                    periodic_shifts_.push_back({{i*lengths[0],j*lengths[1],k*lengths[2]}});
    for (std::size_t i = 0; coplanar_ && i < periodic_shifts_.size(); ++i)
        if (std::fabs(dot(periodic_shifts_[i],plane_normal_)) >
            1.e-10*std::sqrt(norm_squared(periodic_shifts_[i])))
            coplanar_ = false;
}

int GranularThermalWall::build_node(int begin, int end)
{
    Node node;
    node.begin = begin;
    node.end = end;
    node.left = node.right = -1;
    for (int i = begin; i < end; ++i) {
        node.bounds.include(triangles_[i].bounds.lower);
        node.bounds.include(triangles_[i].bounds.upper);
    }
    const int index = static_cast<int>(nodes_.size());
    nodes_.push_back(node);
    if (end-begin <= 8) return index;

    const Vector width = node.bounds.upper-node.bounds.lower;
    const int axis = static_cast<int>(std::max_element(width.begin(),width.end()) - width.begin());
    const int middle = begin+(end-begin)/2;
    std::nth_element(triangles_.begin()+begin, triangles_.begin()+middle, triangles_.begin()+end,
        [axis](const Triangle &a, const Triangle &b) {
            return a.bounds.lower[axis]+a.bounds.upper[axis] < b.bounds.lower[axis]+b.bounds.upper[axis];
        });
    const int left = build_node(begin,middle);
    const int right = build_node(middle,end);
    nodes_[index].left = left;
    nodes_[index].right = right;
    return index;
}

double GranularThermalWall::radial_distance(const double *point) const
{
    const double a = point[(axis_+1)%3]-parameters_[1];
    const double b = point[(axis_+2)%3]-parameters_[2];
    return std::hypot(a,b);
}

double GranularThermalWall::triangle_distance_squared(const Triangle &face, const Vector &point)
{
    const Vector offset = point-face.a;
    const Vector b = face.ab, c = face.ac;
    const double d = dot(offset,face.normal);
    const Vector projected = offset-d*face.normal;
    if (dot(cross(b,projected),face.normal) >= 0.0 &&
        dot(cross(c-b,projected-b),face.normal) >= 0.0 &&
        dot(cross(-1.0*c,projected-c),face.normal) >= 0.0) return d*d;
    return std::min(segment_distance_squared(offset,b),
               std::min(segment_distance_squared(offset,c),segment_distance_squared(offset-b,c-b)));
}

double GranularThermalWall::nearest_squared(int index, const Vector &point, double best) const
{
    const Node &node = nodes_[index];
    if (node.bounds.distance_squared(point) >= best) return best;
    if (node.left < 0) {
        for (int i = node.begin; i < node.end; ++i)
            best = std::min(best,triangle_distance_squared(triangles_[i],point));
        return best;
    }
    int first = node.left, second = node.right;
    if (nodes_[second].bounds.distance_squared(point) < nodes_[first].bounds.distance_squared(point))
        std::swap(first,second);
    return nearest_squared(second,point,nearest_squared(first,point,best));
}

double GranularThermalWall::distance(const double *point) const
{
    if (kind_ == PLANE) return std::fabs(point[axis_]-parameters_[0]);
    if (kind_ == CYLINDER) return std::fabs(radial_distance(point)-parameters_[0]);
    double best = std::numeric_limits<double>::infinity();
    if (nodes_.empty()) return best;
    const Vector center = make_vector(point);
    best = nearest_squared(0,center,best);
    for (std::size_t i = 0; i < periodic_shifts_.size(); ++i)
        best = nearest_squared(0,center-periodic_shifts_[i],best);
    return std::sqrt(best);
}

bool GranularThermalWall::first_triangle_hit(int index, const Vector &point,
        const Vector &direction, double tolerance, Hit &hit) const
{
    const Node &node = nodes_[index];
    if (!node.bounds.intersects(point,direction,hit.distance)) return false;
    if (node.left >= 0) {
        const bool left = first_triangle_hit(node.left,point,direction,tolerance,hit);
        const bool right = first_triangle_hit(node.right,point,direction,tolerance,hit);
        return left || right;
    }
    bool found = false;
    for (int i = node.begin; i < node.end; ++i) {
        const Triangle &face = triangles_[i];
        const Vector p = cross(direction,face.ac);
        const double determinant = dot(face.ab,p);
        const double angle = std::fabs(dot(direction,face.normal));
        if (angle <= 1.e-13 || determinant == 0.0) continue;
        const Vector offset = point-face.a;
        const double u = dot(offset,p)/determinant;
        if (u < -1.e-12 || u > 1.0+1.e-12) continue;
        const Vector q = cross(offset,face.ab);
        const double v = dot(direction,q)/determinant;
        if (v < -1.e-12 || u+v > 1.0+1.e-12) continue;
        const double t = dot(face.ac,q)/determinant;
        if (t <= tolerance || t >= hit.distance) continue;
        hit.distance = t;
        hit.normal_projection = angle;
        found = true;
    }
    return found;
}

bool GranularThermalWall::first_hit(const double *point, const double *direction,
                                   double length, Hit &hit) const
{
    const double tolerance = 1.e-12*length;
    hit.distance = length;
    hit.cylinder_interior = false;
    if (kind_ == TRIANGLES) {
        if (nodes_.empty()) return false;
        const Vector center = make_vector(point), ray = make_vector(direction);
        bool found = first_triangle_hit(0,center,ray,tolerance,hit);
        for (std::size_t i = 0; i < periodic_shifts_.size(); ++i)
            found = first_triangle_hit(0,center-periodic_shifts_[i],ray,tolerance,hit) || found;
        return found;
    }

    if (kind_ == PLANE) {
        if (direction[axis_] == 0.0) return false;
        const double t = (parameters_[0]-point[axis_])/direction[axis_];
        if (t <= tolerance || t >= length) return false;
        hit.distance = t;
        hit.normal_projection = std::fabs(direction[axis_]);
        return true;
    }

    const int a = (axis_+1)%3, b = (axis_+2)%3;
    const double x = point[a]-parameters_[1], y = point[b]-parameters_[2];
    const double ua = direction[a], ub = direction[b], radius = parameters_[0];
    const double quadratic = ua*ua+ub*ub;
    if (quadratic == 0.0) return false;
    const double projection = x*ua+y*ub;
    const double rho = std::hypot(x,y);
    const double constant = (rho-radius)*(rho+radius);
    const double discriminant = projection*projection-quadratic*constant;
    if (discriminant < 0.0) return false;
    const double q = -projection-std::copysign(std::sqrt(discriminant),projection);
    if (q == 0.0) return false;
    double t0 = q/quadratic, t1 = constant/q;
    if (t0 > t1) std::swap(t0,t1);
    const double t = t0 > tolerance ? t0 : t1;
    if (t <= tolerance || t >= length) return false;
    hit.distance = t;
    hit.normal_projection = std::min(1.0,std::fabs(projection+quadratic*t)/radius);
    hit.cylinder_interior = rho < radius;
    return true;
}

double GranularThermalWall::penetration(const double *point, const double *direction,
                                       double radius, const Hit &hit) const
{
    if (!hit.cylinder_interior) return (radius-hit.distance)*hit.normal_projection;
    const int a = (axis_+1)%3, b = (axis_+2)%3;
    const double x = point[a]-parameters_[1]+radius*direction[a];
    const double y = point[b]-parameters_[2]+radius*direction[b];
    return std::max(0.0,std::hypot(x,y)-parameters_[0]);
}

double GranularThermalWall::angular_limit(const double *point, double radius, Vector &axis) const
{
    if (kind_ == PLANE) {
        axis.fill(0.0);
        const double s = parameters_[0]-point[axis_];
        axis[axis_] = s >= 0.0 ? 1.0 : -1.0;
        return std::min(1.0,std::fabs(s)/radius);
    }
    if (kind_ == TRIANGLES) {
        if (!coplanar_) return -1.0;
        const double s = dot(triangles_.front().a-make_vector(point),plane_normal_);
        axis = (s >= 0.0 ? 1.0 : -1.0)*plane_normal_;
        return std::min(1.0,std::fabs(s)/radius);
    }

    const double rho = radial_distance(point);
    if (rho == 0.0) return -1.0;
    const double wall_radius = parameters_[0];
    const int a = (axis_+1)%3, b = (axis_+2)%3;
    const double sign = rho < wall_radius ? 1.0 : -1.0;
    axis.fill(0.0);
    axis[a] = sign*(point[a]-parameters_[1])/rho;
    axis[b] = sign*(point[b]-parameters_[2])/rho;
    if (rho >= wall_radius) return std::min(1.0,(rho-wall_radius)/radius);
    const double lower = ((wall_radius-rho)*(wall_radius+rho)-radius*radius)/(2.0*rho*radius);
    return std::max(-1.0,std::min(1.0,lower));
}

}  // namespace LAMMPS_NS
