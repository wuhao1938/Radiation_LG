/* ----------------------------------------------------------------------
    This is the

    ██╗     ██╗ ██████╗  ██████╗  ██████╗ ██╗  ██╗████████╗███████╗
    ██║     ██║██╔════╝ ██╔════╝ ██╔════╝ ██║  ██║╚══██╔══╝██╔════╝
    ██║     ██║██║  ███╗██║  ███╗██║  ███╗███████║   ██║   ███████╗
    ██║     ██║██║   ██║██║   ██║██║   ██║██╔══██║   ██║   ╚════██║
    ███████╗██║╚██████╔╝╚██████╔╝╚██████╔╝██║  ██║   ██║   ███████║
    ╚══════╝╚═╝ ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝®

    DEM simulation engine, released by
    DCS Computing Gmbh, Linz, Austria
    http://www.dcs-computing.com, office@dcs-computing.com

    LIGGGHTS® is part of CFDEM®project:
    http://www.liggghts.com | http://www.cfdem.com

    Core developer and main author:
    Christoph Kloss, christoph.kloss@dcs-computing.com

    LIGGGHTS® is open-source, distributed under the terms of the GNU Public
    License, version 2 or later. It is distributed in the hope that it will
    be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
    of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. You should have
    received a copy of the GNU General Public License along with LIGGGHTS®.
    If not, see http://www.gnu.org/licenses . See also top-level README
    and LICENSE files.

    LIGGGHTS® and CFDEM® are registered trade marks of DCS Computing GmbH,
    the producer of the LIGGGHTS® software and the CFDEM®coupling software
    See http://www.cfdem.com/terms-trademark-policy for details.

-------------------------------------------------------------------------
    Contributing author and copyright for this file:
    (if not contributing author is listed, this file has been contributed
    by the core developer)

    Copyright 2012-     DCS Computing GmbH, Linz
    Copyright 2009-2012 JKU Linz
------------------------------------------------------------------------- */

#include "fix_heat_gran_conduction.h"

#include "atom.h"
#include "compute_pair_gran_local.h"
#include "domain.h"
#include "fix_property_atom.h"
#include "fix_property_global.h"
#include "fix_wall_gran.h"
#include "force.h"
#include "math_extra.h"
#include "mpi_liggghts.h"
#include "properties.h"
#include "modify.h"
#include "neigh_list.h"
#include "neighbor.h"
#include "pair_gran.h"
#include "tri_mesh.h"
#include "update.h"
#include <cmath>
#include <algorithm>
#include <limits>
#include <utility>

using namespace LAMMPS_NS;
using namespace FixConst;

// modes for conduction contact area calaculation
// same as in fix_wall_gran.cpp

enum{ CONDUCTION_CONTACT_AREA_OVERLAP,
      CONDUCTION_CONTACT_AREA_CONSTANT,
      CONDUCTION_CONTACT_AREA_PROJECTION};

namespace {
const double shell_half_width = 0.20;
const double stefan_boltzmann = 5.670374419e-8;
const double contact_view_factor = 0.5 - 4.0 / (3.0 * M_PI);
const double packing_solid_fraction = 0.61;
const double distribution_amplitude = 0.6291155909;
const double attenuation_diameter = 2.2016769979;
const double gauss_nodes[4] = {-0.8611363115940526, -0.3399810435848563,
                              0.3399810435848563,  0.8611363115940526};
const double gauss_weights[4] = {0.3478548451374539, 0.6521451548625461,
                                 0.6521451548625461, 0.3478548451374539};
const int polar_panels = 16;
const int azimuth_count = 64;
const double temperature_fit_width = 0.75;

double fourth_power(double t)
{
    const double t2 = t*t;
    return t2*t2;
}

double radial_neighbor_density(double eta)
{
    return 24.0 * packing_solid_fraction * eta*eta *
           (1.0 + distribution_amplitude * std::exp(-attenuation_diameter * (eta - 1.0)));
}

double integrated_neighbor_density(double eta)
{
    const double b = attenuation_diameter;
    const double tail = std::exp(-b * (eta - 1.0)) *
                        (eta*eta/b + 2.0*eta/(b*b) + 2.0/(b*b*b));
    return 24.0 * packing_solid_fraction *
           (eta*eta*eta/3.0 - distribution_amplitude*tail);
}

}

// Integrate the angular fraction and the fourth power occupied by one plane.
FixHeatGranCond::ShellCap FixHeatGranCond::planar_shell(double s, double d,
        double eta_lo, double eta_hi, double wall_temp, double slope)
{
    ShellCap result = {0.0, 0.0};
    const double eta_start = std::max(eta_lo, s/d);
    if (eta_start >= eta_hi) return result;

    // Split the radial rule where the extrapolated temperature first reaches 0 K.
    double limits[3] = {eta_start, eta_hi, eta_hi};
    if (slope > 0.0)
        limits[1] = std::max(eta_start, std::min(eta_hi, (s + wall_temp/slope)/d));
    for (int k = 0; k < 2; ++k) {
        const double width = 0.5 * (limits[k+1] - limits[k]);
        if (width <= 0.0) continue;
        const double mid = limits[k] + width;
        for (int q = 0; q < 4; ++q) {
            const double eta = mid + width * gauss_nodes[q];
            const double r = eta*d;
            const double raw = wall_temp + slope * (s-r);
            const double far = std::max(0.0, raw);
            const double w2 = wall_temp*wall_temp;
            const double f2 = far*far;
            const double product = wall_temp*far;
            double average4 = (w2*w2 + product*(w2 + product + f2) + f2*f2)/5.0;
            if (raw < 0.0) average4 *= wall_temp/(wall_temp-raw);
            const double cap_count = width * gauss_weights[q] * radial_neighbor_density(eta)
                                   * (r-s)/(2.0*r);
            result.count += cap_count;
            result.sum_t4 += cap_count * average4;
        }
    }
    return result;
}

/* ---------------------------------------------------------------------- */

FixHeatGranCond::FixHeatGranCond(class LAMMPS *lmp, int narg, char **arg) :
  FixHeatGran(lmp, narg, arg),
  emissivity_(0.0),
  shell_center_(1.42617),
  contact_resistance_(0.0),
  fix_conductivity_(0),
  conductivity_(0),
  store_contact_data_(false),
  fix_conduction_contact_area_(0),
  fix_n_conduction_contacts_(0),
  fix_wall_heattransfer_coeff_(0),
  fix_wall_temperature_(0),
  conduction_contact_area_(0),
  n_conduction_contacts_(0),
  wall_heattransfer_coeff_(0),
  wall_temp_(0),
  area_calculation_mode_(CONDUCTION_CONTACT_AREA_OVERLAP),
  fixed_contact_area_(0.),
  area_correction_flag_(0),
  deltan_ratio_(0)
{
  iarg_ = 5;

  bool hasargs = true;
  while(iarg_ < narg && hasargs)
  {
    hasargs = false;
    if(strcmp(arg[iarg_],"contact_area") == 0) {

      if(strcmp(arg[iarg_+1],"overlap") == 0)
        area_calculation_mode_ =  CONDUCTION_CONTACT_AREA_OVERLAP;
      else if(strcmp(arg[iarg_+1],"projection") == 0)
        area_calculation_mode_ =  CONDUCTION_CONTACT_AREA_PROJECTION;
      else if(strcmp(arg[iarg_+1],"constant") == 0)
      {
        if (iarg_+3 > narg)
            error->fix_error(FLERR,this,"not enough arguments for keyword 'contact_area constant'");
        area_calculation_mode_ =  CONDUCTION_CONTACT_AREA_CONSTANT;
        fixed_contact_area_ = force->numeric(FLERR,arg[iarg_+2]);
        if (fixed_contact_area_ <= 0.)
            error->fix_error(FLERR,this,"'contact_area constant' value must be > 0");
        iarg_++;
      }
      else error->fix_error(FLERR,this,"expecting 'overlap', 'projection' or 'constant' after 'contact_area'");
      iarg_ += 2;
      hasargs = true;
    } else if(strcmp(arg[iarg_],"area_correction") == 0) {
      if (iarg_+2 > narg) error->fix_error(FLERR,this,"not enough arguments for keyword 'area_correction'");
      if(strcmp(arg[iarg_+1],"yes") == 0)
        area_correction_flag_ = 1;
      else if(strcmp(arg[iarg_+1],"no") == 0)
        area_correction_flag_ = 0;
      else error->fix_error(FLERR,this,"expecting 'yes' or 'no' after 'area_correction'");
      iarg_ += 2;
      hasargs = true;
    } else if(strcmp(arg[iarg_],"store_contact_data") == 0) {
      if (iarg_+2 > narg) error->fix_error(FLERR,this,"not enough arguments for keyword 'store_contact_data'");
      if(strcmp(arg[iarg_+1],"yes") == 0)
        store_contact_data_ = true;
      else if(strcmp(arg[iarg_+1],"no") == 0)
        store_contact_data_ = false;
      else error->fix_error(FLERR,this,"expecting 'yes' or 'no' after 'store_contact_data'");
      iarg_ += 2;
      hasargs = true;
    } else if(strcmp(arg[iarg_],"emissivity") == 0 ||
              strcmp(arg[iarg_],"radiation") == 0) {
      if (iarg_+2 > narg)
        error->fix_error(FLERR,this,"missing particle emissivity");
      emissivity_ = force->numeric(FLERR,arg[iarg_+1]);
      if (!(emissivity_ >= 0.0 && emissivity_ <= 1.0))
        error->fix_error(FLERR,this,"particle emissivity must be in [0,1]");
      iarg_ += 2;
      hasargs = true;
    } else if(strcmp(arg[iarg_],"contact_resistance") == 0) {
      if (iarg_+2 > narg)
        error->fix_error(FLERR,this,"missing particle-particle contact resistance");
      contact_resistance_ = force->numeric(FLERR,arg[iarg_+1]);
      if (!(contact_resistance_ > 0.0) || !std::isfinite(contact_resistance_))
        error->fix_error(FLERR,this,"contact_resistance must be positive and finite");
      iarg_ += 2;
      hasargs = true;
    } else if(strcmp(arg[iarg_],"rstar") == 0) {
      if (iarg_+2 > narg)
        error->fix_error(FLERR,this,"missing shell center after 'rstar'");
      shell_center_ = force->numeric(FLERR,arg[iarg_+1]);
      if (!std::isfinite(shell_center_) || shell_center_ <= 1.0)
        error->fix_error(FLERR,this,"'rstar' must be a finite center distance divided by diameter and > 1");
      iarg_ += 2;
      hasargs = true;
    } else if(strcmp(style,"heat/gran/conduction") == 0 || strcmp(style,"heat/gran") == 0)
        error->fix_error(FLERR,this,"unknown keyword");
  }

  if(CONDUCTION_CONTACT_AREA_OVERLAP != area_calculation_mode_ && 1 == area_correction_flag_)
    error->fix_error(FLERR,this,"can use 'area_correction' only for 'contact_area = overlap'");
}

/* ---------------------------------------------------------------------- */

FixHeatGranCond::~FixHeatGranCond()
{

  if (conductivity_)
    delete []conductivity_;
}

/* ---------------------------------------------------------------------- */

void FixHeatGranCond::post_create()
{
  FixHeatGran::post_create();

  // register contact storage
  fix_conduction_contact_area_ = static_cast<FixPropertyAtom*>(modify->find_fix_property("contactAreaConduction","property/atom","scalar",0,0,this->style,false));
  if(!fix_conduction_contact_area_ && store_contact_data_)
  {
    const char* fixarg[10];
    fixarg[0]="contactAreaConduction";
    fixarg[1]="all";
    fixarg[2]="property/atom";
    fixarg[3]="contactAreaConduction";
    fixarg[4]="scalar";
    fixarg[5]="no";
    fixarg[6]="yes";
    fixarg[7]="no";
    fixarg[8]="0.";
    fix_conduction_contact_area_ = modify->add_fix_property_atom(9,const_cast<char**>(fixarg),style);
  }

  fix_n_conduction_contacts_ = static_cast<FixPropertyAtom*>(modify->find_fix_property("nContactsConduction","property/atom","scalar",0,0,this->style,false));
  if(!fix_n_conduction_contacts_ && store_contact_data_)
  {
    const char* fixarg[10];
    fixarg[0]="nContactsConduction";
    fixarg[1]="all";
    fixarg[2]="property/atom";
    fixarg[3]="nContactsConduction";
    fixarg[4]="scalar";
    fixarg[5]="no";
    fixarg[6]="yes";
    fixarg[7]="no";
    fixarg[8]="0.";
    fix_n_conduction_contacts_ = modify->add_fix_property_atom(9,const_cast<char**>(fixarg),style);
  }

  fix_wall_heattransfer_coeff_ = static_cast<FixPropertyAtom*>(modify->find_fix_property("wallHeattransferCoeff","property/atom","scalar",0,0,this->style,false));
  if(!fix_wall_heattransfer_coeff_ && store_contact_data_)
  {
    const char* fixarg[10];
    fixarg[0]="wallHeattransferCoeff";
    fixarg[1]="all";
    fixarg[2]="property/atom";
    fixarg[3]="wallHeattransferCoeff";
    fixarg[4]="scalar";
    fixarg[5]="no";
    fixarg[6]="yes";
    fixarg[7]="no";
    fixarg[8]="0.";
    fix_wall_heattransfer_coeff_ = modify->add_fix_property_atom(9,const_cast<char**>(fixarg),style);
  }

  fix_wall_temperature_ = static_cast<FixPropertyAtom*>(modify->find_fix_property("wallTemp","property/atom","scalar",0,0,this->style,false));
  if(!fix_wall_temperature_ && store_contact_data_)
  {
    const char* fixarg[10];
    fixarg[0]="wallTemp";
    fixarg[1]="all";
    fixarg[2]="property/atom";
    fixarg[3]="wallTemp";
    fixarg[4]="scalar";
    fixarg[5]="no";
    fixarg[6]="yes";
    fixarg[7]="no";
    fixarg[8]="0.";
    fix_wall_temperature_ = modify->add_fix_property_atom(9,const_cast<char**>(fixarg),style);
  }

  if(store_contact_data_ && (!fix_conduction_contact_area_ || !fix_n_conduction_contacts_ || !fix_wall_heattransfer_coeff_ || !fix_wall_temperature_))
    error->one(FLERR,"internal error");
}

/* ---------------------------------------------------------------------- */

void FixHeatGranCond::pre_delete(bool unfixflag)
{

  // tell cpl that this fix is deleted
  if(cpl && unfixflag) cpl->reference_deleted();

}

/* ---------------------------------------------------------------------- */

int FixHeatGranCond::setmask()
{
  int mask = FixHeatGran::setmask();
  mask |= PRE_FORCE;
  mask |= POST_FORCE;
  return mask;
}

/* ---------------------------------------------------------------------- */

void FixHeatGranCond::updatePtrs()
{
  FixHeatGran::updatePtrs();

  if(store_contact_data_)
  {
    conduction_contact_area_ = fix_conduction_contact_area_->vector_atom;
    n_conduction_contacts_ = fix_n_conduction_contacts_->vector_atom;
    wall_heattransfer_coeff_ = fix_wall_heattransfer_coeff_->vector_atom;
    wall_temp_ = fix_wall_temperature_->vector_atom;
  }
}

/* ---------------------------------------------------------------------- */

void FixHeatGranCond::init()
{
  // initialize base class
  FixHeatGran::init();

  if ((contact_resistance_ > 0.0 || emissivity_ > 0.0) &&
      strcmp(update->unit_style,"si") != 0)
    error->fix_error(FLERR,this,"contact_resistance and emissivity require SI units");
  if ((contact_resistance_ > 0.0 || emissivity_ > 0.0) && force->newton_pair)
    error->fix_error(FLERR,this,"the extended heat/gran model requires 'newton off'");

  thermal_walls_.clear();
  if (emissivity_ > 0.0) {
    if (neighbor->contactDistanceFactor + 1.e-12 < shell_center_ + shell_half_width)
      error->fix_error(FLERR,this,"neigh_modify contact_distance_factor must cover rstar + 0.20");
    if (!std::isfinite(T0) || T0 <= 0.0)
      error->fix_error(FLERR,this,"radiation requires a positive initial temperature in kelvin");
  }

  const double *Y, *nu, *Y_orig;
  double expo, Yeff_ij, Yeff_orig_ij, ratio;
  int max_type = atom->get_properties()->max_type();

  if (contact_resistance_ == 0.0) {
    delete []conductivity_;
    conductivity_ = NULL;
    fix_conductivity_ = static_cast<FixPropertyGlobal*>(
        modify->find_fix_property("thermalConductivity","property/global","peratomtype",max_type,0,style));
    conductivity_ = new double[max_type];
    for(int i=0; i<max_type; ++i) {
      conductivity_[i] = fix_conductivity_->compute_vector(i);
      if(conductivity_[i] < 0.0)
        error->all(FLERR,"Fix heat/gran/conduction: Thermal conductivity must not be < 0");
    }
  }

  // calculate heat transfer correction

  if(area_correction_flag_)
  {
    if(!force->pair_match("gran",0))
        error->fix_error(FLERR,this,"area correction only works with using granular pair styles");

    expo = 1./pair_gran->stressStrainExponent();

    Y = static_cast<FixPropertyGlobal*>(modify->find_fix_property("youngsModulus","property/global","peratomtype",max_type,0,style))->get_values();
    nu = static_cast<FixPropertyGlobal*>(modify->find_fix_property("poissonsRatio","property/global","peratomtype",max_type,0,style))->get_values();
    Y_orig = static_cast<FixPropertyGlobal*>(modify->find_fix_property("youngsModulusOriginal","property/global","peratomtype",max_type,0,style))->get_values();

    // allocate a new array within youngsModulusOriginal
    static_cast<FixPropertyGlobal*>(modify->find_fix_property("youngsModulusOriginal","property/global","peratomtype",max_type,0,style))->new_array(max_type,max_type);

    // feed deltan_ratio into this array
    for(int i = 1; i < max_type+1; i++)
    {
      for(int j = 1; j < max_type+1; j++)
      {
        Yeff_ij      = 1./((1.-pow(nu[i-1],2.))/Y[i-1]     +(1.-pow(nu[j-1],2.))/Y[j-1]);
        Yeff_orig_ij = 1./((1.-pow(nu[i-1],2.))/Y_orig[i-1]+(1.-pow(nu[j-1],2.))/Y_orig[j-1]);
        ratio = pow(Yeff_ij/Yeff_orig_ij,expo);
        
        static_cast<FixPropertyGlobal*>(modify->find_fix_property("youngsModulusOriginal","property/global","peratomtype",max_type,0,style))->array_modify(i-1,j-1,ratio);
      }
    }

    // get reference to deltan_ratio
    deltan_ratio_ = static_cast<FixPropertyGlobal*>(modify->find_fix_property("youngsModulusOriginal","property/global","peratomtype",max_type,0,style))->get_array_modified();
  }

  updatePtrs();

  // error checks on coarsegraining
  
}

/* ---------------------------------------------------------------------- */

void FixHeatGranCond::setup(int /*vflag*/)
{
  if (emissivity_ <= 0.0) return;
  prepare_thermal_walls();
}

void FixHeatGranCond::prepare_thermal_walls()
{
  thermal_walls_.clear();
  int rank;
  const bool periodic[3] = {domain->xperiodic != 0,domain->yperiodic != 0,domain->zperiodic != 0};
  const double *periods = domain->triclinic ? NULL : domain->prd;
  MPI_Comm_rank(world,&rank);
  for (int n = 0; ; ++n) {
    Fix *fix = modify->find_fix_style_strict("wall/gran", n);
    if (!fix) break;
    FixWallGran *wall = static_cast<FixWallGran *>(fix);
    if (!wall->is_mesh_wall()) {
      ThermalWall body = {};
      int axis;
      double parameters[3];
      const int count = wall->thermal_primitive(axis,parameters);
      if (!count) continue;
      body.wall = wall;
      body.is_plane = count == 1;
      body.geometry.set_primitive(axis,count,parameters);
      thermal_walls_.push_back(std::move(body));
      continue;
    }
    for (int m = 0; m < wall->n_meshes(); ++m) {
      TriMesh *mesh = wall->mesh_list()[m]->triMesh();
      if (mesh->isMoving() || mesh->isDeforming())
        error->all(FLERR,"Shell radiation supports stationary STL geometry");
      if (domain->triclinic && (periodic[0] || periodic[1] || periodic[2]))
        error->all(FLERR,"Periodic STL radiation uses an orthogonal simulation box");
      const int local_count = mesh->isParallel() || rank == 0 ? mesh->sizeLocal() : 0;
      std::vector<double> coordinates(9*static_cast<std::size_t>(local_count));
      for (int face = 0; face < local_count; ++face)
        for (int node = 0; node < 3; ++node)
          mesh->node(face,node,&coordinates[9*face+3*node]);
      double *all_coordinates = NULL;
      const int total = MPI_Allgather_Vector(coordinates.data(),
          static_cast<int>(coordinates.size()),all_coordinates,world);
      ThermalWall body = {};
      body.wall = wall;
      body.mesh = mesh;
      body.geometry.set_triangles(all_coordinates,total);
      delete []all_coordinates;
      if (periods) body.geometry.set_periodic(periodic,periods);
      thermal_walls_.push_back(std::move(body));
    }
  }
}

/* ---------------------------------------------------------------------- */

void FixHeatGranCond::pre_force(int vflag)
{
    
    if(store_contact_data_)
    {
        fix_wall_heattransfer_coeff_->set_all(0.);
        fix_wall_temperature_->set_all(0.);
    }
}

/* ---------------------------------------------------------------------- */

void FixHeatGranCond::post_force(int vflag)
{

  if(history_flag == 0 && CONDUCTION_CONTACT_AREA_OVERLAP == area_calculation_mode_)
    post_force_eval<0,CONDUCTION_CONTACT_AREA_OVERLAP>(vflag,0);
  if(history_flag == 1 && CONDUCTION_CONTACT_AREA_OVERLAP == area_calculation_mode_)
    post_force_eval<1,CONDUCTION_CONTACT_AREA_OVERLAP>(vflag,0);

  if(history_flag == 0 && CONDUCTION_CONTACT_AREA_CONSTANT == area_calculation_mode_)
    post_force_eval<0,CONDUCTION_CONTACT_AREA_CONSTANT>(vflag,0);
  if(history_flag == 1 && CONDUCTION_CONTACT_AREA_CONSTANT == area_calculation_mode_)
    post_force_eval<1,CONDUCTION_CONTACT_AREA_CONSTANT>(vflag,0);

  if(history_flag == 0 && CONDUCTION_CONTACT_AREA_PROJECTION == area_calculation_mode_)
    post_force_eval<0,CONDUCTION_CONTACT_AREA_PROJECTION>(vflag,0);
  if(history_flag == 1 && CONDUCTION_CONTACT_AREA_PROJECTION == area_calculation_mode_)
    post_force_eval<1,CONDUCTION_CONTACT_AREA_PROJECTION>(vflag,0);
  if (emissivity_ > 0.0 && !update->setupflag) add_radiation();
}

/* ---------------------------------------------------------------------- */

FixHeatGranCond::ShellCap FixHeatGranCond::wall_shell(const double *point, double d,
        double eta_lo, double eta_hi, const double *distances)
{
  ShellCap result = {0.0, 0.0};
  contributing_walls_.clear();
  radial_limits_.clear();
  radial_limits_.push_back(eta_lo);
  radial_limits_.push_back(eta_hi);
  for (std::size_t w = 0; w < thermal_walls_.size(); ++w) {
    const double eta_wall = distances[w]/d;
    if (eta_wall >= eta_hi) continue;
    contributing_walls_.push_back(static_cast<int>(w));
    if (eta_wall > eta_lo) radial_limits_.push_back(eta_wall);
  }
  if (contributing_walls_.empty()) return result;

  if (contributing_walls_.size() == 1) {
    const int w = contributing_walls_.front();
    const ThermalWall &wall = thermal_walls_[w];
    if (wall.is_plane && wall.temperature > 0.0)
      return planar_shell(distances[w],d,eta_lo,eta_hi,wall.temperature,wall.slope);
  }

  std::sort(radial_limits_.begin(),radial_limits_.end());
  const ThermalWall &first_wall = thermal_walls_[contributing_walls_.front()];
  static const std::vector<std::pair<double,double> > azimuths = [] {
    std::vector<std::pair<double,double> > values;
    for (int k = 0; k < azimuth_count; ++k) {
      const double angle = 2.0*M_PI*(k+0.5)/azimuth_count;
      values.push_back(std::make_pair(std::cos(angle),std::sin(angle)));
    }
    return values;
  }();

  for (std::size_t interval = 1; interval < radial_limits_.size(); ++interval) {
    const double width = 0.5*(radial_limits_[interval]-radial_limits_[interval-1]);
    if (width <= 0.0) continue;
    const double midpoint = radial_limits_[interval-1]+width;
    for (int ir = 0; ir < 4; ++ir) {
      const double eta = midpoint+width*gauss_nodes[ir];
      const double r = eta*d;
      const double radial_weight = width*gauss_weights[ir]*radial_neighbor_density(eta);
      GranularThermalWall::Vector axis = {{1.0,0.0,0.0}};
      double mu_min = -1.0;
      if (contributing_walls_.size() == 1)
        mu_min = first_wall.geometry.angular_limit(point,r,axis);
      if (mu_min >= 1.0) continue;
      // Choose two unit vectors perpendicular to the polar axis.
      const int j = std::fabs(axis[0]) < 0.8 ? 0 : 1;
      const double length = std::sqrt(1.0-axis[j]*axis[j]);
      GranularThermalWall::Vector tangent;
      for (int a = 0; a < 3; ++a)
        tangent[a] = ((a == j ? 1.0 : 0.0)-axis[a]*axis[j])/length;
      GranularThermalWall::Vector binormal = {{
          axis[1]*tangent[2]-axis[2]*tangent[1],
          axis[2]*tangent[0]-axis[0]*tangent[2],
          axis[0]*tangent[1]-axis[1]*tangent[0]}};

      const double step = (1.0-mu_min)/polar_panels;
      const double angular_scale = 0.25*step*radial_weight/azimuth_count;
      for (int panel = 0; panel < polar_panels; ++panel)
        for (int q = 0; q < 4; ++q) {
          const double mu = mu_min+step*(panel+0.5+0.5*gauss_nodes[q]);
          const double transverse = std::sqrt(std::max(0.0,1.0-mu*mu));
          const double sample_weight = angular_scale*gauss_weights[q];
          for (std::size_t p = 0; p < azimuths.size(); ++p) {
            double direction[3];
            for (int a = 0; a < 3; ++a)
              direction[a] = mu*axis[a]+transverse*
                  (azimuths[p].first*tangent[a]+azimuths[p].second*binormal[a]);
            GranularThermalWall::Hit first_hit = {r,0.0,false};
            const ThermalWall *surface = NULL;
            for (std::size_t k = 0; k < contributing_walls_.size(); ++k) {
              const int w = contributing_walls_[k];
              const ThermalWall &wall = thermal_walls_[w];
              if (distances[w] >= first_hit.distance) continue;
              GranularThermalWall::Hit hit;
              if (wall.geometry.first_hit(point,direction,first_hit.distance,hit)) {
                first_hit = hit;
                surface = &wall;
              }
            }
            // An unheated wall can intercept and shield a heated wall behind it.
            if (!surface || surface->temperature <= 0.0) continue;
            const double depth = surface->geometry.penetration(point,direction,r,first_hit);
            const double extended = std::max(0.0,surface->temperature-surface->slope*depth);
            result.count += sample_weight;
            result.sum_t4 += sample_weight*fourth_power(extended);
          }
        }
    }
  }
  return result;
}

/* ---------------------------------------------------------------------- */

void FixHeatGranCond::add_radiation()
{
  const int nlocal = atom->nlocal;
  const double *radius = atom->radius;
  const int *mask = atom->mask;
  const NeighList *list = pair_gran->list;
  double **x = atom->x;

  radiation_stats_.assign(nlocal, RadiationStats());
  const int nall = nlocal + atom->nghost;
  temperature4_.resize(nall);
  for (int i = 0; i < nall; ++i) temperature4_[i] = fourth_power(Temp[i]);

  const double eta_lo = std::max(1.0, shell_center_ - shell_half_width);
  const double eta_hi = shell_center_ + shell_half_width;
  const double lo_squared = eta_lo*eta_lo;
  const double hi_squared = eta_hi*eta_hi;
  const std::size_t wall_count = thermal_walls_.size();
  const double infinity = std::numeric_limits<double>::infinity();
  wall_distances_.assign(nlocal*wall_count,infinity);
  std::vector<double> local(2*wall_count,0.0), global(local.size(),0.0);
  for (std::size_t w = 0; w < wall_count; ++w) {
    ThermalWall &wall = thermal_walls_[w];
    wall.temperature = wall.wall->thermal_wall_temperature(wall.mesh);
    if (!std::isfinite(wall.temperature)) wall.temperature = -1.0;
    wall.slope = 0.0;
    for (int i = 0; i < nlocal; ++i) {
      if (!(mask[i] & groupbit) || !(mask[i] & wall.wall->groupbit)) continue;
      const double distance = wall.geometry.distance(x[i]);
      wall_distances_[i*wall_count+w] = distance;
      const double fit_distance = temperature_fit_width*(2.0*radius[i]);
      if (!(wall.temperature > 0.0) || !(distance > 0.0 && distance <= fit_distance)) continue;
      local[2*w] += distance*(Temp[i]-wall.temperature);
      local[2*w+1] += distance*distance;
    }
  }
  if (wall_count) {
    MPI_Allreduce(local.data(),global.data(),static_cast<int>(local.size()),MPI_DOUBLE,MPI_SUM,world);
    for (std::size_t w = 0; w < wall_count; ++w)
      if (global[2*w+1] > 0.0) thermal_walls_[w].slope = global[2*w]/global[2*w+1];
  }

  for (int ii = 0; ii < list->inum; ++ii) {
    const int i = list->ilist[ii];
    if (i >= nlocal) continue;
    const bool active_i = (mask[i] & groupbit) != 0;
    const int *history = history_flag ? pair_gran->listgranhistory->firstneigh[i] : NULL;
    for (int jj = 0; jj < list->numneigh[i]; ++jj) {
      const int j = list->firstneigh[i][jj] & NEIGHMASK;
      const bool active_j = j < nlocal && (mask[j] & groupbit);
      if (!active_i && !active_j) continue;
      const double dx = x[i][0] - x[j][0];
      const double dy = x[i][1] - x[j][1];
      const double dz = x[i][2] - x[j][2];
      const double rsq = dx*dx + dy*dy + dz*dz;
      const double pair_d = radius[i] + radius[j];
      const double pair_d2 = pair_d*pair_d;
      const bool overlap = rsq < pair_d2;
      const bool contact = overlap && (!history || history[jj]);
      const bool shell = !overlap && rsq >= lo_squared*pair_d2 && rsq <= hi_squared*pair_d2;
      if (!contact && !shell) continue;
      if (shell && wall_count) {
        const double separation = std::sqrt(rsq);
        const double direction[3] = {-dx/separation,-dy/separation,-dz/separation};
        bool blocked = false;
        for (std::size_t w = 0; w < wall_count; ++w) {
          const ThermalWall &wall = thermal_walls_[w];
          if (!(mask[i] & wall.wall->groupbit) && !(mask[j] & wall.wall->groupbit)) continue;
          if (wall_distances_[i*wall_count+w] >= separation &&
              (mask[i] & groupbit) && (mask[i] & wall.wall->groupbit)) continue;
          GranularThermalWall::Hit hit;
          if (wall.geometry.first_hit(x[i],direction,separation,hit)) {
            blocked = true;
            break;
          }
        }
        if (blocked) continue;
      }

      // A half-list entry contributes to each owned endpoint.
      if (active_i) {
        RadiationStats &stats = radiation_stats_[i];
        if (contact) {
          ++stats.contact_count;
          stats.contact_t4 += temperature4_[j];
        } else {
          ++stats.shell_count;
          stats.shell_t4 += temperature4_[j];
        }
      }
      if (active_j) {
        RadiationStats &stats = radiation_stats_[j];
        if (contact) {
          ++stats.contact_count;
          stats.contact_t4 += temperature4_[i];
        } else {
          ++stats.shell_count;
          stats.shell_t4 += temperature4_[i];
        }
      }
    }
  }

  const double full_shell_count = integrated_neighbor_density(eta_hi) -
                                  integrated_neighbor_density(eta_lo);
  const double scale = emissivity_ * stefan_boltzmann * M_PI;
  for (int i = 0; i < nlocal; ++i) {
    if (!(mask[i] & groupbit)) continue;
    const RadiationStats &stats = radiation_stats_[i];
    const double d = 2.0*radius[i];
    const double ti4 = temperature4_[i];

    int n_contact = stats.contact_count;
    double contact_sum_t4 = stats.contact_t4;
    const double *distances = wall_count ? &wall_distances_[i*wall_count] : NULL;
    for (std::size_t w = 0; w < wall_count; ++w) {
      const ThermalWall &wall = thermal_walls_[w];
      if (distances[w] > radius[i] || !(wall.temperature > 0.0)) continue;
      ++n_contact;
      const double ghost = FixWallGran::extrapolated_contact_temperature(wall.temperature,Temp[i]);
      contact_sum_t4 += fourth_power(std::max(0.0,ghost));
    }
    const ShellCap cap = wall_shell(x[i],d,eta_lo,eta_hi,distances);

    const double contact_weight = contact_view_factor*n_contact;
    const double shell_weight = 1.0 - contact_weight;
    if (shell_weight < 0.0)
      error->one(FLERR,"Contact radiative view factors exceed unity");
    const double contact_t4 = n_contact > 0 ? contact_sum_t4/n_contact : ti4;
    const double particle_shell_t4 = stats.shell_count > 0 ?
        stats.shell_t4/stats.shell_count : ti4;
    // The wall's weight goes to zero with its cap area, even if the real shell is empty.
    const double shell_t4 = particle_shell_t4 +
        (cap.sum_t4-cap.count*particle_shell_t4)/std::max(full_shell_count,cap.count);
    heatFlux[i] += scale*d*d *
        (contact_weight*(contact_t4 - ti4) + shell_weight*(shell_t4 - ti4));
  }
}

/* ---------------------------------------------------------------------- */

void FixHeatGranCond::cpl_evaluate(ComputePairGranLocal *caller)
{
  if(caller != cpl) error->all(FLERR,"Illegal situation in FixHeatGranCond::cpl_evaluate");

  if(history_flag == 0 && CONDUCTION_CONTACT_AREA_OVERLAP == area_calculation_mode_)
    post_force_eval<0,CONDUCTION_CONTACT_AREA_OVERLAP>(0,1);
  if(history_flag == 1 && CONDUCTION_CONTACT_AREA_OVERLAP == area_calculation_mode_)
    post_force_eval<1,CONDUCTION_CONTACT_AREA_OVERLAP>(0,1);

  if(history_flag == 0 && CONDUCTION_CONTACT_AREA_CONSTANT == area_calculation_mode_)
    post_force_eval<0,CONDUCTION_CONTACT_AREA_CONSTANT>(0,1);
  if(history_flag == 1 && CONDUCTION_CONTACT_AREA_CONSTANT == area_calculation_mode_)
    post_force_eval<1,CONDUCTION_CONTACT_AREA_CONSTANT>(0,1);

  if(history_flag == 0 && CONDUCTION_CONTACT_AREA_PROJECTION == area_calculation_mode_)
    post_force_eval<0,CONDUCTION_CONTACT_AREA_PROJECTION>(0,1);
  if(history_flag == 1 && CONDUCTION_CONTACT_AREA_PROJECTION == area_calculation_mode_)
    post_force_eval<1,CONDUCTION_CONTACT_AREA_PROJECTION>(0,1);
}

/* ---------------------------------------------------------------------- */

template <int HISTFLAG,int CONTACTAREA>
void FixHeatGranCond::post_force_eval(int vflag,int cpl_flag)
{
  double hc,contactArea,delta_n,flux,dirFlux[3];
  int i,j,ii,jj,inum,jnum;
  double xtmp,ytmp,ztmp,delx,dely,delz;
  double radi,radj,radsum,rsq,r,tcoi,tcoj;
  int *ilist,*jlist,*numneigh,**firstneigh;
  int *contact_flag,**first_contact_flag;

  int newton_pair = force->newton_pair;

  if (strcmp(force->pair_style,"hybrid")==0)
    error->warning(FLERR,"Fix heat/gran/conduction implementation may not be valid for pair style hybrid");
  if (strcmp(force->pair_style,"hybrid/overlay")==0)
    error->warning(FLERR,"Fix heat/gran/conduction implementation may not be valid for pair style hybrid/overlay");

  inum = pair_gran->list->inum;
  ilist = pair_gran->list->ilist;
  numneigh = pair_gran->list->numneigh;
  firstneigh = pair_gran->list->firstneigh;
  if(HISTFLAG) first_contact_flag = pair_gran->listgranhistory->firstneigh;

  double *radius = atom->radius;
  double **x = atom->x;
  int *type = atom->type;
  int nlocal = atom->nlocal;
  int *mask = atom->mask;

  updatePtrs();

  if(store_contact_data_)
  {
    fix_conduction_contact_area_->set_all(0.);
    fix_n_conduction_contacts_->set_all(0.);
  }

  // loop over neighbors of my atoms
  for (ii = 0; ii < inum; ii++) {
    i = ilist[ii];
    xtmp = x[i][0];
    ytmp = x[i][1];
    ztmp = x[i][2];
    radi = radius[i];
    jlist = firstneigh[i];
    jnum = numneigh[i];
    if(HISTFLAG) contact_flag = first_contact_flag[i];

    for (jj = 0; jj < jnum; jj++) {
      j = jlist[jj];
      j &= NEIGHMASK;

      if (!(mask[i] & groupbit) && !(mask[j] & groupbit)) continue;

      if(!HISTFLAG)
      {
        delx = xtmp - x[j][0];
        dely = ytmp - x[j][1];
        delz = ztmp - x[j][2];
        rsq = delx*delx + dely*dely + delz*delz;
        radj = radius[j];
        radsum = radi + radj;
      }

      if ((HISTFLAG && contact_flag[jj]) || (!HISTFLAG && (rsq < radsum*radsum))) {  //contact
        
        if(HISTFLAG)
        {
          delx = xtmp - x[j][0];
          dely = ytmp - x[j][1];
          delz = ztmp - x[j][2];
          rsq = delx*delx + dely*dely + delz*delz;
          radj = radius[j];
          radsum = radi + radj;
          if(rsq >= radsum*radsum) continue;
        }

        r = sqrt(rsq);

        if(CONTACTAREA == CONDUCTION_CONTACT_AREA_OVERLAP)
        {
            
            if(area_correction_flag_)
            {
              delta_n = radsum - r;
              delta_n *= deltan_ratio_[type[i]-1][type[j]-1];
              r = radsum - delta_n;
            }

            if (r < fmax(radi, radj)) // one sphere is inside the other
            {
                // set contact area to area of smaller sphere
                contactArea = fmin(radi,radj);
                contactArea *= contactArea * M_PI;
            }
            else
                //contact area of the two spheres
                contactArea = - M_PI/4.0 * ( (r-radi-radj)*(r+radi-radj)*(r-radi+radj)*(r+radi+radj) )/(r*r);
        }
        else if (CONTACTAREA == CONDUCTION_CONTACT_AREA_CONSTANT)
            contactArea = fixed_contact_area_;
        else if (CONTACTAREA == CONDUCTION_CONTACT_AREA_PROJECTION)
        {
            double rmax = std::max(radi,radj);
            contactArea = M_PI*rmax*rmax;
        }

        if (contact_resistance_ > 0.0)
          hc = 1.0 / contact_resistance_;
        else {
          tcoi = conductivity_[type[i]-1];
          tcoj = conductivity_[type[j]-1];
          if (tcoi < SMALL_FIX_HEAT_GRAN || tcoj < SMALL_FIX_HEAT_GRAN) hc = 0.;
          else hc = 4.*tcoi*tcoj/(tcoi+tcoj)*sqrt(contactArea);
        }

        flux = (Temp[j]-Temp[i])*hc;

        dirFlux[0] = flux*delx;
        dirFlux[1] = flux*dely;
        dirFlux[2] = flux*delz;
        if(!cpl_flag)
        {
          //Add half of the flux (located at the contact) to each particle in contact
          heatFlux[i] += flux;
          directionalHeatFlux[i][0] += 0.50 * dirFlux[0];
          directionalHeatFlux[i][1] += 0.50 * dirFlux[1];
          directionalHeatFlux[i][2] += 0.50 * dirFlux[2];

          if(store_contact_data_)
          {
              conduction_contact_area_[i] += contactArea;
              n_conduction_contacts_[i] += 1.;
          }
          if (newton_pair || j < nlocal)
          {
            heatFlux[j] -= flux;
            directionalHeatFlux[j][0] += 0.50 * dirFlux[0];
            directionalHeatFlux[j][1] += 0.50 * dirFlux[1];
            directionalHeatFlux[j][2] += 0.50 * dirFlux[2];

            if(store_contact_data_)
            {
                conduction_contact_area_[j] += contactArea;
                n_conduction_contacts_[j] += 1.;
            }
          }
        }

        if(cpl_flag && cpl) cpl->add_heat(i,j,flux);
      }
    }
  }

  if(newton_pair)
  {
    fix_heatFlux->do_reverse_comm();
    fix_directionalHeatFlux->do_reverse_comm();
    fix_conduction_contact_area_->do_reverse_comm();
    fix_n_conduction_contacts_->do_reverse_comm();
  }

  if(!cpl_flag && store_contact_data_)
  for(int i = 0; i < nlocal; i++)
  {
     if(n_conduction_contacts_[i] > 0.5)
        conduction_contact_area_[i] /= n_conduction_contacts_[i];
  }
}

/* ----------------------------------------------------------------------
   register and unregister callback to compute
------------------------------------------------------------------------- */

void FixHeatGranCond::register_compute_pair_local(ComputePairGranLocal *ptr)
{
   
   if(cpl != NULL)
      error->all(FLERR,"Fix heat/gran/conduction allows only one compute of type pair/local");
   cpl = ptr;
}

void FixHeatGranCond::unregister_compute_pair_local(ComputePairGranLocal *ptr)
{
   
   if(cpl != ptr)
       error->all(FLERR,"Illegal situation in FixHeatGranCond::unregister_compute_pair_local");
   cpl = NULL;
}
