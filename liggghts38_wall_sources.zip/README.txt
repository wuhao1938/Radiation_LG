LIGGGHTS-PUBLIC 3.8.0 平壁、圆柱壁和 STL 壁面换热
基准源码 3d5c00f20519e6bb6eb6756f51f1ad36564e649d

从压缩包复制 src/ 中的六个文件到 LIGGGHTS 的 src/，或在基准源码根目录应用补丁。
git apply --check /path/to/liggghts38_wall_radiation.patch
git apply /path/to/liggghts38_wall_radiation.patch
在 src/ 中清理旧对象文件，再用原项目的编译配置重新编译。

下列命令为输入片段。按照原算例设置材料属性和颗粒生成命令。
units si 和 newton off 应放在 create_box 或 read_restart 前。
颗粒温度以及壁温使用 K。contact_resistance 为球–球参考热阻，单位 K/W。
rstar 为球壳中心位置除以粒径，半厚度固定为 0.20d。

variable eta equal 1.42617
variable skin_factor equal v_eta+0.20
neighbor 0.003 bin
neigh_modify delay 0 every 1 check yes contact_distance_factor ${skin_factor}
fix th all heat/gran/conduction initial_temperature 378.15 &
    emissivity 0.8 rstar ${eta} contact_resistance 12.0

平壁示例
fix wp all wall/gran model hertz tangential history &
    primitive type 1 xplane 0.0 temperature 873.15

圆柱壁示例
fix wc all wall/gran model hertz tangential history &
    primitive type 1 zcylinder 0.6 0.0 0.0 temperature 873.15

STL 示例
fix cad all mesh/surface file wall.stl type 1 temperature 873.15
fix ws all wall/gran model hertz tangential history mesh n_meshes 1 meshes cad

本模型用于等径球。圆柱内外侧由颗粒球心相对于圆柱轴的位置确定。
STL 支持固定、每张网格统一温度的壁面，允许开口曲面及薄挡板。
STL 在 run 初始化时构建 BVH，每个 MPI rank 保存一份。
STL 与周期边界组合时使用固定尺寸的正交计算域。
接触壁面使用镜像温度 2Tw-Ti，等效壁接触热阻为 Rc/2。
非接触球壳按实际邻居计数，每个方向的壁面权重分给首先命中的壁面。
颗粒间的非接触系数按单颗粒归一化，因此全域辐射功率可能有残差。
